import { Component, OnInit } from '@angular/core';
import { FormGroup } from "@angular/forms";
import { FormControl } from "@angular/forms";
import { Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { ToastrService } from 'ngx-toastr';
import { LoginService } from "src/app/login.service";
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-resetpassword',
  templateUrl: './resetpassword.component.html',
  styleUrls: ['./resetpassword.component.css']
})
export class ResetpasswordComponent implements OnInit {
  form = new FormGroup({
    password: new FormControl('', [Validators.required, Validators.minLength(6)]),
    cnfpassword: new FormControl('', [Validators.required, Validators.minLength(6)])
  })

  resetData:any={};
  constructor(private router: Router,private activatedrout:ActivatedRoute, 
    private toastr: ToastrService, private loginService: LoginService) {

  }
  resetClick() {
    if (this.form.value.password === this.form.value.cnfpassword) {
     
      this.resetData = {
        "password": this.form.value.password,
        "email": this.activatedrout.snapshot.params.email
      };
      console.log( JSON.stringify(this.resetData));
      this.loginService.resetPassword(JSON.stringify(this.resetData)).subscribe((res) => {
        console.log(res);
        if (res.success) {
          this.form.reset();
          this.router.navigate(['/login']);
          this.toastr.success('Success', res.message);
          
        }  else {
          this.toastr.error('Error', res.message);
        }
      });

    } else {
      this.toastr.error('MissMatch password', 'Confirm password doesnot match');
    }
  }

  ngOnInit() {
  }
  backLogin() {
    this.router.navigate(['/login']);
  }
}
