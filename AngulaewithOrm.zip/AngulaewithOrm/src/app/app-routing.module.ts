import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from "src/app/login/login.component";
import { RegisterComponent } from "src/app/register/register.component";
import { ResetpasswordComponent } from "src/app/resetpassword/resetpassword.component";
import { ForgotpasswordComponent } from "src/app/forgotpassword/forgotpassword.component";
import { HomeComponent } from "src/app/home/home.component";

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'resetpassword/:email', component: ResetpasswordComponent },
  { path: 'forgotpassword', component: ForgotpasswordComponent },
  { path: 'home', component: HomeComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
