import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { FormGroup } from "@angular/Forms";
import { FormControl } from "@angular/Forms";
import { Validators } from "@angular/Forms";
import { ToastrService } from 'ngx-toastr';
import { LoginService } from "src/app/login.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  form = new FormGroup({
    email: new FormControl('', [Validators.required, Validators.email]),
    password: new FormControl('', [Validators.required, Validators.minLength(6)])
  })

  constructor(private router: Router, private toastr: ToastrService,
    private loginservice: LoginService
  ) {

  }

  ngOnInit() {
  }
  registerNav() {
    this.router.navigate(['/register']);
  }

  forgotNav() {
    this.router.navigate(['/forgotpassword']);
  }

  login() {
    
    console.log(JSON.stringify(this.form.value));
    
    this.loginservice.loginAuth(JSON.stringify(this.form.value)).subscribe((res)=>{
      console.log(res.success);
      if(res.success){
        this.form.reset();
         this.router.navigate(['/home']);
        this.toastr.success('Success', res.message);
       
      }else{
        this.toastr.error('Error', 'Failed to Login');
      }
      
    });


  }
}
