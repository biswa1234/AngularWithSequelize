export class Register{
    name: String;
    password: String;
    email: String;

}